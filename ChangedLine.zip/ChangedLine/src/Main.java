import difflib.Delta;
import difflib.DiffUtils;
import difflib.Patch;
import javafx.util.Pair;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {

    private static Patch fileDiff(String file1, String file2) {

        //if(revised == null || revised.fileContents == null) return MAX_LINE_COUNT;
        // gets the patch diff of th files
        List<String> file1_list = Arrays.asList(file1.split("\\r?\\n"));
        List<String> file2_list = Arrays.asList(file2.split("\\r?\\n"));
        Patch patch = DiffUtils.diff(file1_list, file2_list);

        return patch;

       // System.out.println(patch);
        // gets the changes in the diff
/*        List<Delta> changes = patch.getDeltas();

        // gets the start line(can be more precise if set)
        int startLine = (comment.start_line == 0) ? comment.line_number : comment.start_line;
        int endLine = (comment.end_line == 0) ? comment.line_number : comment.end_line;

        int commentStartRange= startLine - MAX_CHANGE_RANGE;
        int commentEndRange=endLine + MAX_CHANGE_RANGE;

        // loop through the changes to find if a change corresponds to the line number
        for (Delta change : changes) {
            // checks if the change is made in this delta;
            // DELETIONS store lines of the original file in the revised copies
            int changeStart=change.getOriginal().getPosition();
            int changeEnd=changeStart+ change.getOriginal().size();


            if(isOverlappingRange(commentStartRange, commentEndRange, changeStart, changeEnd))
            {
                //commented line among change set
                if(startLine >= changeStart && startLine <= changeEnd)
                    return 0;
                else return Math.min(Math.abs(startLine-changeStart), Math.abs(startLine-changeEnd));
            }
        }

        return MAX_LINE_COUNT;*/

    }


    static boolean isOverlappingRange(int start1,int end1, int start2,int end2) {
        return Math.max(start1, start2)<= Math.min(end1, end2);
    }

    public static void main(String[] args) {
        //System.out.println("Hello World");
        String file1 = "line 1\n" +
                "line 2\n" +
                "line 3\n" +
                "line 4\n" +
                "line 5\n";
        String file2 = "line 1\n" +
                "line 2\n" +
                "line 3\n" + "\n\n"+
                "line 4\n" +
                "line 5\n";
        Patch patch  = fileDiff(file1, file2);
        //System.out.println(patch);
        List<Delta> changes = patch.getDeltas();

        for (Delta change : changes) {
            // checks if the change is made in this delta;
            // DELETIONS store lines of the original file in the revised copies
            int changeStart=change.getOriginal().getPosition();
            int changeEnd=changeStart+ change.getOriginal().size();

            int revisedPos = change.getRevised().getPosition();

            System.out.println(change.getRevised()+", changeStart : "+changeStart+", Original size: "+change.getOriginal().size()
                    +", Revised Size: "+change.getRevised().size()+", Revised Pos: "+revisedPos);
           /* if(isOverlappingRange(commentStartRange, commentEndRange, changeStart, changeEnd))
            {
                //commented line among change set
                if(startLine >= changeStart && startLine <= changeEnd)
                    return 0;
                else return Math.min(Math.abs(startLine-changeStart), Math.abs(startLine-changeEnd));
            }*/
        }
        /*String[] split = "1\n2\n\n3".split("\\r?\\n");
        for(String x:split){
            System.out.println("<"+x+">");
        }
*/
    }
}
